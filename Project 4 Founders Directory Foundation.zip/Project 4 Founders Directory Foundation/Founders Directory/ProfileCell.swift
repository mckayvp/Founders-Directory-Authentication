//
//  ProfileCell.swift
//  Founders Directory
//
//  Created by Steve Liddle on 9/23/16.
//  Copyright © 2016 Steve Liddle. All rights reserved.
//

import UIKit

class ProfileCell : UITableViewCell {
    @IBOutlet var biographyLabel: UILabel!
}
