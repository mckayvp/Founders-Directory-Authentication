//
//  FounderCell.swift
//  Founders Directory
//
//  Created by Steve Liddle on 9/21/16.
//  Copyright © 2016 Steve Liddle. All rights reserved.
//

import UIKit

class FounderCell : UITableViewCell {
    @IBOutlet var founderImageView: UIImageView!
    @IBOutlet var founderNameLabel: UILabel!
    @IBOutlet var founderCompanyLabel: UILabel!
}
